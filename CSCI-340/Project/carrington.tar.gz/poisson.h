#ifndef POISSON_H
#define POISSON_H

void init_poisson(unsigned int seed, double lam);
int poisson();

#endif /* POISSON_H */
